#!/bin/bash

# Download and install anaconda 

curl -O https://mirrors.bfsu.edu.cn/anaconda/archive/Anaconda3-2020.02-Linux-x86_64.sh
sh Anaconda3-2020.02-Linux-x86_64.sh

# Add anaconda into PATH
echo 'export PATH=/opt/anaconda3/bin:$PATH' > /etc/profile.d/anaconda.sh
source /etc/profile.d/anaconda.sh

# Create Virtual Env of python 3.7
conda create -n py37 python=3.7 ipykernel<<EOF
y
EOF

# Add python env into jupyter kernel
cp -r kernels/python3 /opt/anaconda3/share/jupyter/kernels/
