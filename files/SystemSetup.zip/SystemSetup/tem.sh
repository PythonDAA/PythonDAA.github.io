#!/bin/bash
CHAPTERDIRNAME="Chapter1"
# Add regular users
while IFS=, read NAME PW; do
    echo "Copy files to $NAME"
	cp -r ~/$CHAPTERDIRNAME /home/$NAME/lecture_notes
	chown $NAME /home/$NAME/lecture_notes/$CHAPTERDIRNAME/
	chown $NAME /home/$NAME/lecture_notes/$CHAPTERDIRNAME/*
	chgrp users /home/$NAME/lecture_notes/$CHAPTERDIRNAME/
	chgrp users /home/$NAME/lecture_notes/$CHAPTERDIRNAME/*
done < <(egrep -v '^#' data/pya.list)

while IFS=, read NAME PW; do
    echo "Copy files to $NAME"
	cp -r ~/$CHAPTERDIRNAME /home/$NAME/lecture_notes
	chown $NAME /home/$NAME/lecture_notes/$CHAPTERDIRNAME/
	chown $NAME /home/$NAME/lecture_notes/$CHAPTERDIRNAME/*
	chgrp users /home/$NAME/lecture_notes/$CHAPTERDIRNAME/
	chgrp users /home/$NAME/lecture_notes/$CHAPTERDIRNAME/*
done < <(egrep -v '^#' data/pyb.list)