#!/bin/bash

# Add lecturers group
groupadd lecturers
groupadd users
groupadd py2019a
groupadd py2019b

# Add lecturer users
while IFS=, read NAME PW; do
    echo "Creating lecturer $NAME"
    if [ -z $PW ]; then
        useradd -s "/bin/bash" -m -N -g users -G sudo,adm,lecturers $NAME
		echo "$NAME password unset"
    else
        useradd -s "/bin/bash" -m -N -g users -G sudo,adm,lecturers -p "$PW" $NAME
		echo "$NAME:$PW" | chpasswd
    fi
done < <(egrep -v '^#' data/lecturers.list)

# Add regular users
while IFS=, read NAME PW; do
    echo "Creating student $NAME"
    if [ -z $PW ]; then
        useradd -s "/bin/bash" -m -N -g users -G py2019a $NAME
		echo "$NAME password unset"
    else
        useradd -s "/bin/bash" -m -N -g users -G py2019a -p "$PW" $NAME
		echo "$NAME:$PW" | chpasswd
    fi
done < <(egrep -v '^#' data/pya.list)

while IFS=, read NAME PW; do
    echo "Creating student $NAME"
    if [ -z $PW ]; then
        useradd -s "/bin/bash" -m -N -g users -G py2019b $NAME
		echo "$NAME password unset"
    else
        useradd -s "/bin/bash" -m -N -g users -G py2019b -p "$PW" $NAME
		echo "$NAME:$PW" | chpasswd
    fi
done < <(egrep -v '^#' data/pyb.list)