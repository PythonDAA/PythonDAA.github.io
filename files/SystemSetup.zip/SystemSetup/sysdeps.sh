#!/bin/bash
wget https://tuna.moe/oh-my-tuna/oh-my-tuna.py

python3 oh-my-tuna.py --global<<EOF
y
EOF

apt update

# Install system dependencies
#apt install -y npm

# Install configurable-http-proxy
#npm install -g configurable-http-proxy

# Create notebooks folder in each new user's home folder
mkdir -p /etc/skel/notebooks &> /dev/null
if [ ! -d /etc/skel/notebooks ]; then
  mkdir /etc/skel/notebooks
fi

# Create lecture_notes folder in each new user's home folder
mkdir -p /etc/skel/lecture_notes &> /dev/null
if [ ! -d /etc/skel/lecture_notes ]; then
  mkdir /etc/skel/lecture_notes
fi
